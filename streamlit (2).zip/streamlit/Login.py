import streamlit as st
import streamlit_authenticator as stauth
import yaml
from yaml.loader import SafeLoader

def run_authentication_app():
    # Load configuration from config.yaml
    with open('./config.yaml') as file:
        config = yaml.load(file, Loader=SafeLoader)

    # Initialize Streamlit Authenticator
    authenticator = stauth.Authenticate(
        config['credentials'],
        config['cookie']['name'],
        config['cookie']['key'],
        config['cookie']['expiry_days'],
        config['preauthorized']
    )

    # Streamlit UI setup
    st.write("# Welcome to InventoGPT! 👋")
    st.sidebar.success("Select a demo above.")

    # Use the correct 'fields' parameter instead of 'form_name'
    authenticator.login(fields={'Login':'main'})

    if st.session_state["authentication_status"]:
        # Use a dictionary for 'fields' instead of a set
        authenticator.logout('Logout', 'main', key='unique_key')
        st.write(f'Welcome *{st.session_state["name"]}*')
        st.title('Refer to sidebar for more pages!')
    elif st.session_state["authentication_status"] is False:
        st.error('Username/password is incorrect')
    elif st.session_state["authentication_status"] is None:
        st.warning('Please enter your username and password')

    if st.session_state["authentication_status"]:
        try:
            # Use the correct 'fields' parameter instead of 'form_name'
            if authenticator.reset_password(st.session_state["username"], fields={'Reset password': 'main'}):
                st.success('Password modified successfully')
        except Exception as e:
            st.error(e)

    try:
        # Use the correct 'fields' parameter instead of 'form_name'
        if authenticator.register_user(fields={'Register user': 'main'}, preauthorization=False):
            st.success('User registered successfully')
    except Exception as e:
        st.error(e)

# Run the authentication app
if __name__ == "__main__":
    run_authentication_app()
