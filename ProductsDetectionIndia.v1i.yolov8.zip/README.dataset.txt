# ProductsDetectionIndia > 2023-07-06 6:51pm
https://universe.roboflow.com/birlasoft/productsdetectionindia

Provided by a Roboflow user
License: CC BY 4.0

